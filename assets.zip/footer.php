<div style="clear:both;"></div>
<div class="row">
<div class="col-md-12 footer">Copyright &copy;<?php echo date('Y'); ?> <a href="/"><?php bloginfo(); ?></a> All Right Reserved.</div>
</div>
</div>
</body>
</html>
